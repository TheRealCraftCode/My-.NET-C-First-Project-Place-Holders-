Project Title: WindowsAntivirusDef2019



Purpose: Educational research into system behavior and malware simulation.



Inspiration/Credit: Inspired by the research and demonstrations of @ClutterTech. This project is for personal, isolated, educational research purposes only and is not intended for distribution.



Precautions Taken: (List your isolation methods, e.g., "Tested exclusively in an air-gapped VM environment.")

