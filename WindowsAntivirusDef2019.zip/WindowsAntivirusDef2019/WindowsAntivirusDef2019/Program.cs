﻿// This application id totaly not create by me real 100% trust me plz
using System;
using System.IO;
using System.Threading;
using System.Text;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Linq;
using Microsoft.SqlServer.Server;
using System.Security.Principal;

namespace Antivirus2019UltimateEdition
{
    class Program
    {
        string fullUsername = WindowsIdentity.GetCurrent().Name;
        // --- System State & Engine Variables ---
        static readonly string AppVersion = "v2019.8.9-ULTIMATE_BUILD";
        static bool IsActivated = false;
        static int ThreatsFound = 0;
        static bool RtpEnabled = true;
        static string Heuristics = "PARANOID";
        static string Hwid = "AV19-" + Guid.NewGuid().ToString().Substring(0, 12).ToUpper();
        static Random rnd = new Random();

        // Compatibility: .NET Framework doesn't have OperatingSystem.IsWindows()
        // Provide a small helper that works on .NET Framework 4.7.2
        static bool IsWindows()
        {
            var p = Environment.OSVersion.Platform;
            return p == PlatformID.Win32NT || p == PlatformID.Win32S || p == PlatformID.Win32Windows || p == PlatformID.WinCE;
        }

        static void Main(string[] args)
        {
            if (IsWindows())
            {
                Console.Title = "ANTIVIRUS 2019 PRO";
            }

            Console.OutputEncoding = Encoding.UTF8;
            Console.CursorVisible = false;

            BootSequence();

            while (true)
            {
                Console.CursorVisible = true;
                ShowMainMenu();

                string choice = Console.ReadLine() ?? "";

                switch (choice)
                {
                    // There Is A Cuter Way To Do This 
                    //But Im Lazy (or stoopid)
                    case "1": ModuleDeepScan(); break;
                    case "2": ModuleRootkitScanner(); break;
                    case "3": ModuleMemoryScan(); break;
                    case "4": ModuleNetwork(); break;
                    case "5": ModuleQuarantine(); break;
                    case "6": ModuleSettings(); break;
                    case "7": ModuleLogs(); break;
                    case "8": ModuleLicense(); break;
                    case "9": SubsystemTerminal(); break; // Subsystem Terminal
                    case "10": ModuleChckdisk(); break; // check disk
                    case "11": //shutdown option
                        // Shutdown
                        Typewrite("\n[SYSCALL] Sending SIGTERM to Antivirus Daemon...", ConsoleColor.DarkGray, 20);
                        Thread.Sleep(1000);
                        return;
                    default:
                        WriteColor("\n[ERROR] Please Choose The Option Above. Access Denied.", ConsoleColor.Red);
                        Thread.Sleep(1200);
                        break;
                }
            }
        }
        // --- Compiler stuff ---
        // add near other helpers in Program class
        static void PrintBuildLogFromFile(string logPath)
        {
            if (!File.Exists(logPath))
            {
                Console.WriteLine($"Log not found: {logPath}");
                return;
            }
            // Reads the whole file (no escaping required) and prints it
            string content = File.ReadAllText(logPath);
            Console.WriteLine(content);
        }

        // Example call (e.g., in Main or a menu handler)
        // Example usage (uncomment and adjust path if needed):
        // PrintBuildLogFromFile(@"C:\Users\lbxtr\Desktop\J++\SAS OS 1.0.0\il2cpu_snippet.txt");
        // --- Core Boot & UI ---

        static void BootSequence()
        {
            Console.Clear();
            Typewrite("[INIT] Injecting AV2019 Hook into winlogon.exe...", ConsoleColor.DarkGray, 10);
            Thread.Sleep(300);
            Typewrite("[INIT] Bypassing Windows PatchGuard (KPP)... SUCCESS", ConsoleColor.DarkGray, 10);
            Thread.Sleep(300);

            Console.WriteLine();
            Typewrite("[BOOT] Loading Antivirus 2019 Ultimate Daemon...", ConsoleColor.White, 20);

            string arch = Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE") ?? "UNKNOWN_ARCH";
            Typewrite($"[BOOT] Host Architecture: {arch} | Threading: {Environment.ProcessorCount} Cores", ConsoleColor.Cyan, 10);
            Typewrite($"[BOOT] Identity Matrix: {Environment.MachineName} \\ {Environment.UserName}", ConsoleColor.Cyan, 10);

            Console.WriteLine();
            Typewrite("[CHK] Verifying Cryptographic Signatures:", ConsoleColor.White, 15);
            Console.WriteLine(" -> ntdll.dll       ... [VERIFIED]");
            Thread.Sleep(100);
            Console.WriteLine(" -> kernel32.dll    ... [VERIFIED]");
            Thread.Sleep(100);
            Console.WriteLine(" -> hal.dll         ... [VERIFIED]");
            Thread.Sleep(400);

            Console.WriteLine();
            WriteColor("[!] WARNING: AV2019.dll Not Founded", ConsoleColor.Red);
            WriteColor("[!] Attempting forced Ring-0 escalation...", ConsoleColor.Yellow);
            Thread.Sleep(1500);
            Typewrite("[BOOT] Escalation SUCCESS.", ConsoleColor.Green, 20);
            //Mount VFS
            Console.WriteLine();
            DrawProgressBar("Mounting Virtual File System (VFS)...");
            Console.WriteLine("\n[INFO] Boot sequence completed.");
            Thread.Sleep(1000);
        }

        //Use static void because normaly i can't use namespaces methots
        static void ShowMainMenu()
        {
            Console.Clear();
            ConsoleColor mainColor = IsActivated ? ConsoleColor.Green : ConsoleColor.Red;
            Console.ForegroundColor = mainColor;
            // Can't Use Multi-Line Strings in .NET Framework 4.7.2, so i have to use @"" syntax
            Console.WriteLine(@"
    █████╗ ███╗   ██╗████████╗██╗██╗   ██╗██╗██████╗ ██╗   ██╗███████╗
   ██╔══██╗████╗  ██║╚══██╔══╝██║██║   ██║██║██╔══██╗██║   ██║██╔════╝
   ███████║██╔██╗ ██║   ██║   ██║██║   ██║██║██████╔╝██║   ██║███████╗
   ██╔══██║██║╚██╗██║   ██║   ██║╚██╗ ██╔╝██║██╔══██╗██║   ██║╚════██║
   ██║  ██║██║ ╚████║   ██║   ██║ ╚████╔╝ ██║██║  ██║╚██████╔╝███████║
   ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═══╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝ ");

            WriteColor($"\n                        ULTIMATE EDITION {AppVersion}", ConsoleColor.Yellow);
            Console.WriteLine("  ========================================================================\n");

            Console.ResetColor();

            if (IsActivated)
            {
                Console.Write("   [ INTEGRITY: "); WriteColor("SECURE - PROTECTED", ConsoleColor.Green); Console.Write(" ]   ");
                Console.Write("[ LICENSE: "); WriteColor("PRO ACTIVATED", ConsoleColor.Green); Console.WriteLine(" ]");
            }
            else
            {
                Console.Write("   [ INTEGRITY: "); WriteColor("AT RISK - EXPOSED", ConsoleColor.Red); Console.Write(" ]   ");
                Console.Write("[ LICENSE: "); WriteColor("UNREGISTERED EVALUATION", ConsoleColor.DarkYellow); Console.WriteLine(" ]");
            }
            Console.WriteLine($"   [ THREAT ENGINE: {Heuristics} MODE ]");
            Console.WriteLine($"   [ THIS DEFENDER NUMBER: {Hwid} ]\n");

            Console.WriteLine("   [1] SYSTEM DEEP SCAN       (Analyzes all local drives)");
            Console.WriteLine("   [2] MBR SECTOR SCAN (MBR & Hidden Sector Scan)");
            Console.WriteLine("   [3] MEMORY DUMP     (Volatile RAM Analysis)");
            Console.WriteLine("   [4] NETWORK FIREWALL       (Live Packet Sniffer)");
            Console.WriteLine($"   [5] QUARANTINE VAULT       (Threats Contained: {ThreatsFound})");
            Console.WriteLine("   [6] ENGINE CONFIGURATION");
            Console.WriteLine("   [7] EVENT VIEWER LOGS");
            Console.WriteLine("   [8] LICENSE MANAGER");
            Console.WriteLine("   [9] COMMAND LINE SUBSYSTEM (Advanced Users Only)");
            Console.WriteLine("   [10] CHECK DISK UlTILITY\n");
            Console.WriteLine("   [11] SHUTDOWN DAEMON\n");
            Console.Write("   root@AV2019:~#");                     
        }

        // --- Scanning Modules ---

        static void ModuleDeepScan()
        {
            Console.Clear();
            Console.WriteLine($"[MODULE] HEURISTIC DEEP SCAN | THREADS: {Environment.ProcessorCount}");
            Console.WriteLine("===================================================================\n");
            Thread.Sleep(500);
            Typewrite("[>] Compiling File Index Master Table (MFT)...", ConsoleColor.White, 10);
            Typewrite("[>] Injecting YARA ruleset (2,109,482 signatures)...", ConsoleColor.White, 10);
            Console.WriteLine();
            Thread.Sleep(800);

            int filesScanned = 0;
            string[] dirs = { @"C:\Windows\System32", @"C:\Users\Admin\AppData", @"C:\ProgramData\Microsoft", @"D:\Backups", @"C:\Windows", @"C:\", @"D:\" };
            string[] exts = { ".sys", ".dll", ".exe", ".dat", ".bin", ".log", " (Folders)", ".Dump" };

            for (int i = 0; i < 100; i++)
            {
                filesScanned += rnd.Next(1, 15);
                string path = $"{dirs[rnd.Next(dirs.Length)]}\\{Guid.NewGuid().ToString().Substring(0, 8)}{exts[rnd.Next(exts.Length)]}";
                string size = rnd.Next(12, 4096) + " KB";

                Console.Write($"[SCAN] ");
                WriteColor($"{path}".PadRight(50), ConsoleColor.DarkGray);
                Console.WriteLine($" {size}");

                if (rnd.Next(0, 100) < 4) // 4% chance
                {
                    WriteColor($"\n[!!!] MALWARE SIGNATURE MATCHED [!!!]", ConsoleColor.Red);
                    WriteColor($"[!!!] PATH: {path}", ConsoleColor.Red);
                    WriteColor($"[!!!] TYPE: Trojan.Win32.Ransom.{rnd.Next(100, 999)}\n", ConsoleColor.Red);
                    ThreatsFound++;
                    if (IsWindows()) Console.Beep(800, 200);
                    Thread.Sleep(800);
                }
                Thread.Sleep(rnd.Next(10, 50));
            }

            Console.WriteLine($"\n[INFO] Scan Terminated. Total Files: {filesScanned} | Infections: {ThreatsFound}");
            Thread.Sleep(2000);
            ScanSummary();
        }

        static void ModuleRootkitScanner()
        {
            Console.Clear();
            WriteColor("[MODULE] MBR ANALYSIS", ConsoleColor.DarkMagenta);
            Console.WriteLine("===================================================================\n");
            Typewrite("Bypassing Windows API... Reading physical disk \x5C\x5C.\x5CPhysicalDrive0...", ConsoleColor.Yellow, 20);
            Thread.Sleep(1000);
            Typewrite("Bypassing Windows API ... Reading Physical Disk \x4c\x4c.\x4cPhysicalDrive1...", ConsoleColor.Yellow, 20);
            Thread.Sleep(1000);
            Console.WriteLine("\nOFFSET     00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F   DECODED TEXT");
            Console.WriteLine("---------  -----------------------------------------------   ------------");

            for (int i = 0; i < 50; i++)
            {
                string offset = $"0x000{rnd.Next(1000, 9999):X4}";
                StringBuilder hex = new StringBuilder();
                StringBuilder ascii = new StringBuilder();

                for (int j = 0; j < 16; j++)
                {
                    int b = rnd.Next(32, 126);
                    hex.Append($"{b:X2} ");
                    ascii.Append((char)b);
                }

                Console.Write($"{offset}   ");
                WriteColor(hex.ToString(), ConsoleColor.DarkCyan);
                Console.SetCursorPosition(61, Console.CursorTop - 1);
                Console.WriteLine(ascii.ToString().Replace(" ", "."));

                if (rnd.Next(0, 100) < 5)
                {
                    Console.WriteLine();
                    WriteColor(">> FATAL: HIDDEN EXECUTABLE CODE DETECTED IN BOOT SECTOR.", ConsoleColor.Red);
                    WriteColor(">> CLASSIFICATION: Rootkit.Boot.SST.a", ConsoleColor.Red);
                    ThreatsFound++;
                    if (IsWindows()) Console.Beep(1000, 300);
                    Thread.Sleep(1000);
                }
                Thread.Sleep(80);
            }

            Typewrite("\n[INFO] Master Boot Record inspection complete.", ConsoleColor.White, 20);
            Thread.Sleep(1500);
            ScanSummary();
        }

        static void ModuleMemoryScan()
        {
            Console.Clear();
            WriteColor("[MODULE] VOLATILE MEMORY DUMP & KERNEL STACK ANALYSIS", ConsoleColor.DarkGreen);
            Console.WriteLine("===================================================================\n");
            Typewrite("Dumping PAGE_EXECUTE_READWRITE memory regions...", ConsoleColor.White, 15);
            Thread.Sleep(500);

            for (int i = 0; i < 50; i++)
            {
                string addr = $"0xFFFF{rnd.Next(100000, 999999):X6}";
                string pid = rnd.Next(100, 9999).ToString().PadLeft(5);

                Console.WriteLine($"[{addr}] PID:{pid} ... THREAD_ALLOC_OK  [R-W-X]");
                Thread.Sleep(25);

                if (rnd.Next(0, 100) < 3)
                {
                    Console.WriteLine();
                    WriteColor($"[!] CRITICAL ANOMALY: UNBACKED EXECUTABLE MEMORY AT {addr}", ConsoleColor.Red);
                    WriteColor($"[!] ASSOCIATED PID: {pid} (svchost.exe - INJECTED)", ConsoleColor.Magenta);
                    WriteColor($"[!] THREAT: Fileless.Malware.CobaltStrike.Beacon", ConsoleColor.Red);
                    ThreatsFound++;
                    if (IsWindows()) Console.Beep(600, 400);
                    Thread.Sleep(1200);
                }
            }
            Typewrite("\n[INFO] Stack analysis and memory dump finished.", ConsoleColor.White, 20);
            Thread.Sleep(1500);
            ScanSummary();
        }

        static void ModuleNetwork()
        {
            Console.Clear();
            WriteColor("[MODULE] LIVE PACKET SNIFFER & TCP/UDP MONITOR", ConsoleColor.Cyan);
            Console.WriteLine("===================================================================\n");

            Typewrite("Hooking into Windows Filtering Platform (WFP)... SUCCESS", ConsoleColor.DarkGray, 10);
            Typewrite("Capturing raw socket data...\n", ConsoleColor.DarkGray, 10);

            Console.WriteLine("PROTOCOL  LOCAL I.P.           FOREIGN I.P.         STATE          GEO-LOOKUP");
            Console.WriteLine("--------  ---------------      ---------------      -------        ----------");

            string[] states = { "ESTABLISHED", "TIME_WAIT", "LISTENING", "SYN_SENT" };
            string[] geos = { "AWS (US)", "AZURE (IE)", "CLOUDFLARE (Global)", "LOCAL_LAN", "AKAMAI (JP)" };

            for (int i = 0; i < 20; i++)
            {
                string proto = rnd.Next(0, 2) == 0 ? "TCP" : "UDP";
                string local = $"192.168.1.100:{rnd.Next(1024, 65535)}".PadRight(20);
                string foreign = $"{rnd.Next(1, 255)}.{rnd.Next(1, 255)}.{rnd.Next(1, 255)}.{rnd.Next(1, 255)}:{rnd.Next(80, 443)}".PadRight(20);
                string state = states[rnd.Next(states.Length)].PadRight(14);
                string geo = geos[rnd.Next(geos.Length)];

                Console.WriteLine($"{proto.PadRight(9)} {local} {foreign} {state} {geo}");
                Thread.Sleep(rnd.Next(100, 500));

                if (i == 14) // Guaranteed threat event
                {
                    WriteColor($"\nTCP       192.168.1.100:4444   194.32.78.10:8080    ESTABLISHED    UNKNOWN (RU) [CRITICAL]", ConsoleColor.Red);
                    if (IsWindows()) Console.Beep(900, 500);
                    WriteColor(">> [FIREWALL ALERT] REVERSE TCP SHELL CONNECTION DETECTED <<", ConsoleColor.Red);
                    WriteColor(">> [FIREWALL ALERT] FOREIGN HOST IS A KNOWN BOTNET C2 NODE <<\n", ConsoleColor.Red);
                    ThreatsFound++;
                    Thread.Sleep(2000);
                }
            }

            Console.WriteLine("\n[INFO] Packet sniffing session ended. Press Enter to return.");
            Console.ReadLine();
        }

        static void SubsystemTerminal()
        {
            Console.Clear();
            WriteColor("===================================================", ConsoleColor.DarkGray);
            WriteColor("   AV2019 KERNEL COMMAND SUBSYSTEM (tty1)", ConsoleColor.DarkGray);
            WriteColor("   Type 'help' for a list of available commands.", ConsoleColor.DarkGray);
            WriteColor("===================================================\n", ConsoleColor.DarkGray);

            while (true)
            {
                Console.Write("C:\\Windows\\System32\\AV_Kernel> ");
                string cmd = (Console.ReadLine() ?? "").Trim().ToLower();

                if (cmd == "exit") break;
                else if (cmd == "help")
                {
                    Console.WriteLine("Available commands:");
                    Console.WriteLine("  status    - View engine integrity");
                    Console.WriteLine("  killall   - Terminate all user-mode processes");
                    Console.WriteLine("  wipe      - Erase quarantine vault");
                    Console.WriteLine("  clear     - Clear terminal screen");
                    Console.WriteLine("  exit      - Return to main dashboard");
                }
                else if (cmd == "status")
                {
                    Console.WriteLine($"Engine: {AppVersion}\nThreats in Memory: {ThreatsFound}\nLicense Active: {IsActivated}");
                }
                else if (cmd == "wipe")
                {
                    if (ThreatsFound == 0) Console.WriteLine("Vault is already empty.");
                    else
                    {
                        Console.WriteLine("Overwriting quarantined sectors with 0x00...");
                        Thread.Sleep(1000);
                        ThreatsFound = 0;
                        Console.WriteLine("Vault wiped successfully.");
                    }
                }
                else if (cmd == "killall")
                {
                    WriteColor("ERROR: Requires SYSTEM level privileges. Current: Administrator.", ConsoleColor.Red);
                }
                else if (cmd == "clear")
                {
                    Console.Clear();
                }
                else if (cmd != "")
                {
                    Console.WriteLine($"'{cmd}' is not recognized as an internal kernel command.");
                }
            }
        }

        // --- Management & Utility ---

        static void ScanSummary()
        {
            Console.Clear();
            WriteColor("[RESULT] HEURISTIC ANALYSIS COMPLETE", ConsoleColor.Yellow);
            Console.WriteLine("===================================================================\n");
            Console.WriteLine($"   TOTAL THREATS DISCOVERED : {ThreatsFound}");
            Console.WriteLine(ThreatsFound > 0 ? "   SYSTEM INTEGRITY         : COMPROMISED\n" : "   SYSTEM INTEGRITY         : SECURE\n");

            Console.WriteLine("   [1] NEUTRALIZE & DELETE ALL THREATS (Requires Pro Activation)");
            Console.WriteLine("   [2] IGNORE AND RETURN TO MENU       (Highly Unsafe)\n");

            Console.Write("   Action:> ");

            string choice = Console.ReadLine() ?? "";

            if (choice == "1")
            {
                if (IsActivated) ExecuteCleanup();
                else
                {
                    Console.Clear();
                    WriteColor("[ERROR] OPERATION DENIED: CRYPTOGRAPHIC LICENSE REQUIRED.", ConsoleColor.Red);
                    Console.WriteLine("\nYour current evaluation license does not permit automated threat removal.");
                    Console.WriteLine("Hackers may still have active access to your machine.");
                    Console.WriteLine("\nPlease navigate to License Management [Option 8].\nPress Enter to return...");
                    Console.ReadLine();
                }
            }
        }

        static void ExecuteCleanup()
        {
            Console.Clear();
            WriteColor("[>] INITIATING KERNEL-LEVEL PURGE...", ConsoleColor.Green);
            DrawProgressBar("Terminating malicious threads and dropping hooks...");
            Thread.Sleep(500);
            DrawProgressBar("Overwriting malicious disk sectors (DoD 5220.22-M)...");
            ThreatsFound = 0;
            Console.WriteLine("\n[SUCCESS] All identified threats have been neutralized and securely wiped.");
            Console.WriteLine("Press Enter to return...");
            Console.ReadLine();
        }

        static void ModuleQuarantine()
        {
            Console.Clear();
            WriteColor("[MODULE] SECURE ENCRYPTED QUARANTINE VAULT", ConsoleColor.Yellow);
            Console.WriteLine("===================================================================\n");

            if (ThreatsFound == 0)
            {
                Console.WriteLine("   Vault is currently empty. No isolated files present.");
            }
            else
            {
                WriteColor($"   WARNING: Vault contains {ThreatsFound} active malicious objects.", ConsoleColor.Red);
                Console.WriteLine("   These objects are encrypted (AES-256) and suspended in virtual memory.\n");
                Console.WriteLine("   ID   ORIGINAL PATH                               THREAT CLASSIFICATION");
                Console.WriteLine("   --   -------------                               ---------------------");
                for (int i = 1; i <= ThreatsFound; i++)
                {
                    Console.WriteLine($"   {i:D2}   C:\\Windows\\Temp\\payload_{rnd.Next(100, 999)}.tmp          Win32.Malware.Gen");
                }
                Console.WriteLine("\n   Run a system cleanup to permanently delete these items.");
            }
            Console.WriteLine("\nPress Enter to return...");
            Console.ReadLine();
        }

        static void ModuleSettings()
        {
            Console.Clear();
            Console.WriteLine("[MODULE] CORE ENGINE CONFIGURATION");
            Console.WriteLine("===================================================================\n");
            Console.WriteLine($"   [1] Real-Time Protection (RTP)  : {(RtpEnabled ? "ON" : "OFF")}");
            Console.WriteLine($"   [2] Heuristics Sensitivity      : {Heuristics}");
            Console.WriteLine("   [3] Reset Configuration to Default");
            Console.WriteLine("   [4] Return to Dashboard\n");

            Console.Write("   Setting:> ");

            string choice = Console.ReadLine() ?? "";

            if (choice == "1") RtpEnabled = !RtpEnabled;
            if (choice == "2") Heuristics = Heuristics == "AGGRESSIVE" ? "PARANOID" : "AGGRESSIVE";
            if (choice == "3") { RtpEnabled = true; Heuristics = "PARANOID"; }
        }

        static void ModuleLogs()
        {
            Console.Clear();
            Console.WriteLine("[MODULE] KERNEL EVENT LOGS");
            Console.WriteLine("===================================================================\n");
            Console.WriteLine($"[{DateTime.Now.AddMinutes(-12):yyyy-MM-dd HH:mm:ss}] [INFO] AV_Core.sys Driver Loaded");
            Console.WriteLine($"[{DateTime.Now.AddMinutes(-10):yyyy-MM-dd HH:mm:ss}] [INFO] Virtual File System Mounted");
            Console.WriteLine($"[{DateTime.Now.AddMinutes(-5):yyyy-MM-dd HH:mm:ss}] [WARN] Bypassed Windows Defender telemetry");
            Console.WriteLine($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [INFO] User accessed dashboard");
            Console.WriteLine("\nPress Enter to return...");
            Console.ReadLine();
        }

        static void ModuleLicense()
        {
            Console.Clear();
            WriteColor("[MODULE] CRYPTOGRAPHIC LICENSE MANAGEMENT", ConsoleColor.Cyan);
            Console.WriteLine("===================================================================\n");
            Console.WriteLine($"   Your Hardware Identification Key (HWID): {Hwid}\n");

            if (IsActivated)
            {
                WriteColor("   STATUS: PRO EDITION ACTIVATED", ConsoleColor.Green);
                Console.WriteLine("   All kernel features, automated removal, and network firewalls are unlocked.\n");
            }
            else
            {
                Console.WriteLine("   STATUS: EVALUATION MODE");
                Console.WriteLine("   To unlock automated threat removal, please enter a valid Pro key.\n");
                Console.Write("   Enter License Key (Hint: type '1337'): ");

                string key = (Console.ReadLine() ?? "").Trim();

                if (key == "1337")
                {
                    IsActivated = true;
                    WriteColor("\n[SUCCESS] RSA-4096 Signature verified. Thank you for purchasing PRO!", ConsoleColor.Green);
                }
                else
                {
                    WriteColor("\n[ERROR] Invalid License Key. Signature mismatch.", ConsoleColor.Red);
                }
            }
            Console.WriteLine("\nPress Enter to return...");
            Console.ReadLine();
        }

        // --- Visual Effects & Utilities ---

        static void WriteColor(string text, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(text);
            Console.ResetColor();
        }

        static void Typewrite(string text, ConsoleColor color, int speedDelay)
        {
            Console.ForegroundColor = color;
            foreach (char c in text)
            {
                Console.Write(c);
                Thread.Sleep(speedDelay);
            }
            Console.WriteLine();
            Console.ResetColor();
        }

        static void DrawProgressBar(string message)
        {
            Console.Write($"{message} [                    ] 0%");
            int left = Console.CursorLeft - 26; // Track where the bar starts

            for (int i = 1; i <= 20; i++)
            {
                Thread.Sleep(rnd.Next(50, 200));
                Console.SetCursorPosition(left, Console.CursorTop);
                Console.Write(new string('#', i).PadRight(20, '-'));
                Console.Write($"] {i * 5}%");
            }
            Console.WriteLine();
        }

        static void ModuleChckdisk()
        {
            Console.Clear();
            WriteColor("[MODULE] CHECK DISK UTILITY", ConsoleColor.DarkYellow);
            Console.WriteLine("===================================================================\n");
            Typewrite("Analyzing file system integrity...", ConsoleColor.White, 15);
            Thread.Sleep(1000);
            Typewrite("Checking for bad sectors and lost clusters...", ConsoleColor.White, 15);
            Thread.Sleep(1000);
            Typewrite("File system check complete. Needing To Fix Disk: C: for broken cluster and bad sector", ConsoleColor.Green, 15);
            DrawProgressBar("Repairing disk sectors and rebuilding file system...");
            Thread.Sleep(1000);
            Typewrite("Checking For Malwares And Viruses In Disk C:...", ConsoleColor.White, 15);
            Thread.Sleep(1000);
            DrawProgressBar("Starting Hardware Scan...");
            Thread.Sleep(1000);
            Typewrite("[>] Compiling File Index Master Table (MFT)...", ConsoleColor.White, 10);
            Typewrite("[>] Injecting YARA ruleset (2,109,482 signatures)...", ConsoleColor.White, 10);
            Console.WriteLine();
            Thread.Sleep(800);
            int filesScanned = 0;
            string[] dirs = { @"C:\Windows\System32", @"C:\Users\\AppData", @"C:\ProgramData\Microsoft", @"D:\Backups", @"C:\Windows", @"C:\", @"D:\" };
            string[] exts = { ".sys", ".dll", ".exe", ".dat", ".bin", ".log", " (Folders)", ".Dump" };

            for (int i = 0; i < 100; i++)
            {
                filesScanned += rnd.Next(1, 15);
                string path = $"{dirs[rnd.Next(dirs.Length)]}\\{Guid.NewGuid().ToString().Substring(0, 8)}{exts[rnd.Next(exts.Length)]}";
                string size = rnd.Next(12, 4096) + " KB";

                Console.Write($"[SCAN] ");
                WriteColor($"{path}".PadRight(50), ConsoleColor.DarkGray);
                Console.WriteLine($" {size}");

                if (rnd.Next(0, 100) < 4) // 4% chance
                {
                    WriteColor($"\n[!!!] MALWARE SIGNATURE MATCHED [!!!]", ConsoleColor.Red);
                    WriteColor($"[!!!] PATH: {path}", ConsoleColor.Red);
                    WriteColor($"[!!!] TYPE: Trojan.Win32.Ransom.{rnd.Next(100, 999)}\n", ConsoleColor.Red);
                    ThreatsFound++;
                    if (IsWindows()) Console.Beep(800, 200);
                    Thread.Sleep(800);
                }
                Thread.Sleep(rnd.Next(10, 50));
            }

            Console.WriteLine($"\n[INFO] Scan Terminated. Total Files: {filesScanned} | Infections: {ThreatsFound}");
            Thread.Sleep(2000);
            ScanSummary();
        }
    }
        }